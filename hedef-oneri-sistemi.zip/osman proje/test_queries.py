import pandas as pd
import os
import io
import sys

# Fix encoding for print
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

class DB:
    def __init__(self):
        file_path = os.path.join('c:/Users/orsul/OneDrive/Рабочий стол/osman proje/guncel_veriler', 'Verileri_SMART Hedefler ve Gerçekleşmeler.xlsx')
        self.df = pd.read_excel(file_path, engine='openpyxl')
        self.df.columns = [str(c).strip() for c in self.df.columns]
        
    def count(self, table):
        return len(self.df)
        
    def query(self, sql):
        if "GROUP BY \"Sicil\"" in sql:
            res = self.df.groupby(['Sicil', 'İsim']).size().reset_index(name='count')
            return res.sort_values('Sicil')
        elif "GROUP BY \"Bölüm Ana Sorumluluk Alanı\"" in sql:
            res = self.df.groupby('Bölüm Ana Sorumluluk Alanı').size().reset_index(name='count')
            return res

db = DB()
total = db.count('goals')
byEmployee = db.query('SELECT "Sicil", "İsim", COUNT(*) as count FROM goals GROUP BY "Sicil", "İsim" ORDER BY "Sicil"')
byDept = db.query('SELECT "Bölüm Ana Sorumluluk Alanı", COUNT(*) as count FROM goals GROUP BY "Bölüm Ana Sorumluluk Alanı"')

print(f"Total: {total}")
print("\nBy Employee:")
print(byEmployee.head(25).to_string())
print("\nBy Dept:")
print(byDept.to_string())

# Check Result Statuses
def normalize(s):
    if pd.isna(s): return ''
    return ' '.join(str(s).strip().lower().split())

self_df = db.df.copy()
self_df['norm_status'] = self_df['Gerçekleşen Değere Göre Sonuç'].apply(normalize)
print("\nResult statuses:")
print(self_df['norm_status'].value_counts())
