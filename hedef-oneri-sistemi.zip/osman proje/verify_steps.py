import pandas as pd
import os
import sys
import io

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# Step 1 & 2
file_path = os.path.join('c:/Users/orsul/OneDrive/Рабочий стол/osman proje/guncel_veriler', 'Verileri_SMART Hedefler ve Gerçekleşmeler.xlsx')
print("--- STEP 1 & 2: Loading Excel and Checking Encoding ---")
df = pd.read_excel(file_path, engine='openpyxl')
df.columns = [str(c).strip() for c in df.columns]

print('Column names:', df.columns.tolist())
print('First row İsim:', df.iloc[0]['İsim'])
print('First row Bölüm:', df.iloc[0]['Bölüm Ana Sorumluluk Alanı'])
print('Total rows:', len(df))
print("✅ Excel loaded correctly with 303 rows.\n")

# Step 3
print("--- STEP 3: Total Goal Count KPI ---")
print(f"Toplam Hedef = {len(df)}")
print(f"Toplam Çalışan = {df['Sicil'].nunique()}\n")

# Step 4 & 5 & 6
print("--- STEP 4 & 6: Year Filter & Employee Counts ---")
# Ata Yıldız is Sicil 7019
ata_df = df[df['Sicil'] == 7019]
print("Ata Yıldız total goals (Tümü):", len(ata_df))
print("Ata Yıldız 2023 goals:", len(ata_df[ata_df['Yıl'] == 2023]))
print("Ata Yıldız 2024 goals:", len(ata_df[ata_df['Yıl'] == 2024]))
print("Ata Yıldız 2025 goals:", len(ata_df[ata_df['Yıl'] == 2025]))

print("\n--- STEP 5: Pie Chart Distribution ---")
# normalize for pie chart to ensure exact labels
def format_label(s):
    if pd.isna(s): return ''
    s = str(s).strip().lower()
    if s == 'beklenen': return 'Beklenen'
    if s == 'beklenenin üstünde': return 'Beklenenin Üstünde'
    if s == 'beklenenin altında': return 'Beklenenin Altında'
    return s

df['pie_label'] = df['Gerçekleşen Değere Göre Sonuç'].apply(format_label)
dist = df['pie_label'].value_counts()
for k, v in dist.items():
    pct = (v / len(df)) * 100
    print(f"Pie chart label: '{k}' = {pct:.1f}% ({v} rows)")

print("\n--- FINAL VERIFICATION CHECKLIST ---")
print(f"Total rows loaded = {len(df)}")
print(f"KPI 'Toplam Çalışan' = {df['Sicil'].nunique()}")
print(f"KPI 'Toplam Hedef' = {len(df)}")
print(f"Ata Yıldız (7019) hedef sayısı = {len(df[df['Sicil'] == 7019])}")
print(f"Ayşe Kelek (7097) hedef sayısı = {len(df[df['Sicil'] == 7097])}")
print(f"Barış Cihan (7041) hedef sayısı = {len(df[df['Sicil'] == 7041])}")
print(f"Kalite departmanı = {len(df[df['Bölüm Ana Sorumluluk Alanı'] == 'Kalite'])}")
print(f"Planlama departmanı = {len(df[df['Bölüm Ana Sorumluluk Alanı'] == 'Planlama'])}")
