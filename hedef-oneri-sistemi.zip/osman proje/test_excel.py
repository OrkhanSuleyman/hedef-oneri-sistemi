import pandas as pd
import os
import io
import sys
from src.config import Config

# Fix encoding for print
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

file_path = os.path.join(Config.DATA_DIR, 'Verileri_SMART Hedefler ve Gerçekleşmeler.xlsx')
print(f"Reading: {file_path}")

try:
    df = pd.read_excel(file_path, engine='openpyxl')
    print("Columns:", df.columns.tolist())
    print("Total rows:", len(df))
    
    if 'Sicil' in df.columns:
        counts = df.groupby('Sicil').size()
        print("\nGoals per employee:")
        print(counts.head())
except Exception as e:
    print("Error:", e)
