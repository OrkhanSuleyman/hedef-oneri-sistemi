# Stratejik Performans Yönetim Sistemi (PMS) - Güncelleme Notları

Bu proje, şirket hedeflerinin ve çalışan performanslarının takibini yapan, Excel tabanlı verileri "tek gerçeklik kaynağı" (Source of Truth) olarak kullanan gelişmiş bir Admin Paneli ve Raporlama sistemidir.

## 🚀 Son Yapılan Yenilikler ve İyileştirmeler

### 1. Veri Entegrasyonu ve Doğruluk (Excel Alignment)
Sistemdeki tüm veriler `Verileri_SMART Hedefler ve Gerçekleşmeler.xlsx` dosyası ile %100 uyumlu hale getirilmiştir.
- **Hedef Sayıları:** Toplam hedef sayısı tam olarak **303** satır olarak güncellendi.
- **Çalışan Listesi:** Sistemdeki benzersiz çalışan sayısı **21** olarak sabitlendi.
- **Departman Bazlı Dağılım:** Departmanların (Kalite, Planlama, Lojistik vb.) hedef sayıları Excel'deki gerçek değerlerle eşleştirildi.
- **Durum Analizi:** 'Beklenen', 'Beklenenin Üstünde' ve 'Beklenenin Altında' gibi performans sonuçları karakter bazlı doğrulukla hesaplanmaktadır.

### 2. Admin Dashboard İyileştirmeleri
- **Yıl Filtresi:** 2023, 2024 ve 2025 yılları için dinamik filtreleme eklendi.
- **Dinamik KPI Kartları:** Toplam çalışan, toplam hedef ve performans oranları anlık olarak filtrelere göre güncellenir.
- **Grafik Güncellemeleri:**
    - "Hedef Sonuç Dağılımı" (Pasta Grafik) gerçek Excel verilerinden beslenmektedir.
    - "Yıllık Hedef Performans Trendi" grafiği eklenerek 2023-2025 arası performans değişimi görselleştirilmiştir.

### 3. Modüler PDF Raporlama Sistemi
Eski ve hatalı olan "Dashboard Yazdır" özelliği kaldırılarak, yerine yüksek çözünürlüklü ve modüler bir PDF sistemi getirilmiştir.
- **4 Farklı Rapor Türü:**
    1. **Şirket Geneli Raporu:** Tüm şirketin KPI ve departman özetlerini içerir.
    2. **Departman Raporu:** Seçilen departmana özel çalışan listesi ve performans tablosu sunar.
    3. **Çalışan Raporu:** Seçilen çalışanın tüm yıllardaki hedeflerini (Ata Yıldız için 12 hedef gibi) detaylı olarak listeler.
    4. **Genel Performans Raporu:** Tüm 21 çalışanın performans özetini tek bir büyük tabloda sunar.
- **Teknik Detaylar:** `html2canvas` ve `jsPDF` kütüphaneleri kullanılarak, gizli şablonlar üzerinden A4 boyutuna tam sığacak şekilde optimize edilmiştir.
- **Okunabilirlik:** PDF boyutları, verilerin kağıda en iyi şekilde sığması için optimize edilmiştir (11px font ve dengeli padding).

### 4. Temizlik ve Performans
- Excel'de bulunmayan "Yapay Zeka Analitiği" gibi sahte veri içeren sekmeler ve grafikler tamamen kaldırıldı.
- Türkçe karakter sorunları (Turkish Encoding) `openpyxl` motoru ve sütun temizleme algoritmaları ile çözüldü.

---

## 🛠 Teknik Mimari
- **Backend:** Python (Streamlit)
- **Veri İşleme:** Pandas, Openpyxl
- **Görselleştirme:** Plotly Express
- **Raporlama:** JavaScript (html2canvas, jsPDF) injection
- **Veri Kaynağı:** `guncel_veriler/Verileri_SMART Hedefler ve Gerçekleşmeler.xlsx`

## 📁 Dosya Yapısı
- `app.py`: Ana uygulama girişi.
- `src/admin_dashboard.py`: Admin panelinin UI ve mantık katmanı.
- `src/pdf_generator.py`: PDF şablonlarını ve JS mantığını üreten modül.
- `src/backend_api.py`: Excel verilerini okuyan ve temizleyen API katmanı.

---
*Bu sistem, stratejik hedeflerin şeffaf ve hatasız bir şekilde raporlanması için tasarlanmıştır.*
