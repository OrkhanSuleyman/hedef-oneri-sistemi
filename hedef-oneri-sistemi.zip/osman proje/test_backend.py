import sys
from src.backend_api import BackendAPI

try:
    api = BackendAPI()
    df_goals = api.get_goals()
    print("Goals loaded:", df_goals.shape)
    
    df_emp = api.get_employees()
    print("Employees loaded:", df_emp.shape)
    
    depts = api.get_departments()
    print("Departments:", depts)
except Exception as e:
    print("Error:", e)
    sys.exit(1)
